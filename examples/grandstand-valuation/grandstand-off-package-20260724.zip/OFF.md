# Grandstand Limited (NASDAQ: GRSD) — Bespoke Equity Valuation

**Valuation date:** 24 July 2026  
**Reporting and output currency:** USD  
**Accounting:** IFRS as issued by the IASB  
**Primary method:** Six-year FCFF DCF  
**Status:** Screen-grade; locally verified formula output; author-declared lineage

## Conclusion

The base FCFF DCF indicates **$8.71 per diluted share**, with a formula-driven
bear/base/bull range of **$3.92–$14.38**, compared with a frozen **$1.73**
closing-price reference from 23 July 2026. The gap is not a trade instruction:
the valuation is highly sensitive to the realization of a restructuring,
stabilization of search traffic, the durability of sports-data growth, and the
debt-like claims deducted from enterprise value.

The current-price read-through is an implied enterprise-value-to-2026
normalized-EBITDA multiple, not a unique market belief. The model records it
only as a diagnostic. The DCF is the primary method; the 4.0x–6.0x EBITDA
range is an analyst stress rather than an independently normalized peer median.

## Business perimeter and method

Grandstand Limited, formerly Gambling.com Group Limited, is a Jersey-incorporated
Nasdaq issuer that changed its ticker from GAMB to GRSD on 23 July 2026. It is a
single reporting segment spanning performance marketing, consumer and enterprise
sports data, advertising and related ticketing. A consolidated FCFF DCF is
appropriate because operating cash flow can be forecast and borrowings can be
bridged separately from operating value.

The model begins with management’s FY2026 revenue guidance of $165–$170 million
and adjusted-EBITDA guidance of $45–$50 million. It converts the midpoint into
FCFF by applying explicit normalized EBITDA margins, D&A, cash taxes, capex and
operating working-capital investment. It adds March 2026 cash and deducts
borrowings, OddsJam deferred consideration and lease liabilities. It uses
42.43 million Q1 2026 diluted weighted-average shares as a conservative
denominator.

## Scenario summary

| Case | Revenue 2026E | EBITDA margin 2031E | WACC | Value / share |
|---|---:|---:|---:|---:|
| Bear | $165.0m | 29.0% | 14.5% | $3.92 |
| Base | $167.5m | 32.5% | 13.0% | $8.71 |
| Bull | $170.0m | 37.0% | 11.5% | $14.38 |

The base discount rate is 12.96% (shown as 13.0%) and terminal growth is 2.5%.
The sensitivity table recalculates value across 11%–15% WACC and 2.0%–3.0%
terminal growth. The base intersection reconciles to the headline DCF output.

## What must be true

- Sports-data and enterprise subscription growth must offset reduced organic
  search visibility and UK / Finland regulatory pressure on marketing revenue.
- The AI transformation-led restructure must deliver a meaningful portion of its
  stated $13 million annualized savings without eroding revenue quality.
- Margin recovery must occur after Q1 2026’s 22% adjusted-EBITDA margin.
- Borrowings, deferred consideration, capitalized development and potential
  dilution must not absorb the forecast operating cash generation.

## Catalysts, risks and evidence limits

The next material proof points are Q2 2026 earnings, cash conversion after
April deferred-consideration settlements, demonstrated cost savings and the
trajectory of data-services growth. Principal risks are search / AI discovery
disruption, gaming regulation, high leverage and earnout obligations, dilution,
and restructuring or integration failure.

The package uses audited FY2023–FY2025 IFRS financial statements, unaudited Q1
2026 interim results, management guidance, and a dated secondary price snapshot.
No licensed consensus, price-history, beta or peer-multiple feed was available;
those inputs are visibly labeled as analyst assumptions or secondary evidence.

## Verification boundary

The workbook contains 169 formulas. A read-only post-export audit confirmed nine
sheets, no cached formula errors and ten passing model checks, including source
ties, FCFF construction, the enterprise-to-equity bridge, scenario ordering,
sensitivity directionality and the base-case intersection. The bundled workbook
runtime exported the file successfully but crashed during its post-export
re-import/render path; visual-render and native-Excel/LibreOffice recalculation
are therefore not claimed. OFF conformance, if passed, validates the package
structure and declared lineage—not the investment assumptions or conclusion.
