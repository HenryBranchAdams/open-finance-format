# Sources

Retrieved 24 July 2026 unless otherwise noted.

## Primary company and regulatory evidence

1. **Gambling.com Group Limited, 2025 Form 20-F**, filed 19 March 2026.
   Audited FY2023–FY2025 IFRS income statement, cash flow, balance sheet,
   revenue mix, adjusted-EBITDA reconciliation, debt and share disclosures.
   <https://www.sec.gov/Archives/edgar/data/1839799/000183979926000048/gamb-20251231.htm>

2. **Gambling.com Group Limited, Q1 2026 Form 6-K and interim financial
   statements**, furnished 14 May 2026. Q1 actuals, March cash, borrowings,
   deferred consideration, diluted shares, NDCs and post-period settlements.
   <https://www.sec.gov/Archives/edgar/data/1839799/000183979926000101/q12026quarterlyfinancials.htm>

3. **Gambling.com Group, Q1 2026 earnings release**, 14 May 2026. Revised
   FY2026 revenue guidance of $165–$170 million, adjusted-EBITDA guidance of
   $45–$50 million, 25% proposed workforce reduction and $13 million annualized
   savings target.
   <https://www.sec.gov/Archives/edgar/data/1839799/000183979926000099/gamb-q12026xpressrelease.htm>

4. **Grandstand, investor-relations services**, retrieved 24 July 2026.
   Confirms Grandstand Limited’s current GRSD ticker and predecessor GAMB ticker.
   <https://grandstand.com/investors/ir-services>

## Market and discount-rate evidence

5. **Robinhood, GRSD quote page**, retrieved 24 July 2026. Secondary market
   snapshot used only to freeze a $1.73 closing-price reference for 23 July.
   Refresh before any decision use.
   <https://robinhood.com/us/en/stocks/GRSD/>

6. **Federal Reserve Board, H.15 Selected Interest Rates**, release dated 22
   July 2026. 10-year Treasury constant-maturity reference of 4.55%.
   <https://www.federalreserve.gov/releases/h15/>

7. **Aswath Damodaran, Implied Equity Risk Premium**, July 2026 update.
   4.18% US implied ERP input. This is an input, not a company-specific result.
   <https://pages.stern.nyu.edu/~adamodar/New_Home_Page/home.htm>

## Evidence limitations

- No licensed consensus, peer-multiple, beta or enterprise-value dataset was
  available. The peer method is explicitly a selected analyst stress, not a
  normalized market median.
- The price snapshot is secondary and the GRSD ticker began trading only on 23
  July 2026; the reference must be refreshed before use.
- Q2 2026 had not been reported. The March cash / debt bridge does not fully
  capture later deferred-consideration settlements, restructure cash costs or
  second-quarter cash generation.
- The model uses management guidance as a starting point and does not assume the
  full benefit of the stated restructure without evidence of realization.
